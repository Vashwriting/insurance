﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace DataBindingusingADONET
{
    public partial class SearchStudent : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Training"].ConnectionString);
        SqlCommand cmd = null;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("SELECT * FROM Student_Master WHERE Stud_Code = @scode", con);
            cmd.Parameters.AddWithValue("@scode", txtSCode.Text);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                txtName.Text = dr["Stud_Name"].ToString();
                txtDCode.Text = dr["Dept_Code"].ToString();
                txtDob.Text = dr["Stud_Dob"].ToString();
                txtAddress.Text = dr["Address"].ToString();
            }
            else
            {
                Response.Write("<script type='text/javascript'>alert('Student not found');</script>");
            }
            con.Close();
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("Update Student_master SET Stud_Name = @sname, Dept_Code = @dcode, Stud_Dob = @dob, Address = @address WHERE Stud_Code = @scode", con);
            cmd.Parameters.AddWithValue("@sname", txtName.Text);
            cmd.Parameters.AddWithValue("@dcode", txtDCode.Text);
            cmd.Parameters.AddWithValue("@dob", Convert.ToDateTime(txtDob.Text));
            cmd.Parameters.AddWithValue("@address", txtAddress.Text);
            cmd.Parameters.AddWithValue("@scode", txtSCode.Text);

            con.Open();
            int recordsAffected = cmd.ExecuteNonQuery();
            con.Close();

            if (recordsAffected > 0)
            {
                Response.Write("<script type='text/javascript'>alert('New Student Updated Successfully');</script>");
                Response.Redirect("Home.aspx");
            }
            else
                Response.Write("<script type='text/javascript'>alert('New Student not updated');</script>");
        }
    }
}